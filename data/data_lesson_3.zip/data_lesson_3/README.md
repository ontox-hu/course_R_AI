## README to datasets lesson 5

### Lesson 2

### Lesson 3

### Lesson 4

### Lesson 5

 - [`delaney-processed.csv`: Data set from the DeepChem Github repo](https://github.com/deepchem/deepchem/blob/master/datasets/delaney-processed.csv)
 - [](https://github.com/chen709847237/SSL-GCN), 
 see also: ./data/lesson5/chen709847237 for download script
